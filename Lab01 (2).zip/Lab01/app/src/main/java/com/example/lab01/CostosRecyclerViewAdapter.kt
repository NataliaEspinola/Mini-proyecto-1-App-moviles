package com.example.lab01

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.navtest.Spend
import java.util.ArrayList

class CostosRecyclerViewAdapter():
    RecyclerView.Adapter<CostosRecyclerViewAdapter.CostosViewHolder>() {

    var data = mutableListOf<Spend>()

    inner class CostosViewHolder(private val view: View): RecyclerView.ViewHolder(view){
        fun bindView(item: Spend){
            val categoryTextView = view.findViewById<TextView>(R.id.category_text_view)
            val totalSpendsTextView = view.findViewById<TextView>(R.id.totalSpends_text_view)
            val totalAmountTextView = view.findViewById<TextView>(R.id.totalAmount_text_view)
            categoryTextView.text = item.totalAmount.toString()
            totalSpendsTextView.text = item.totalSpends.toString()
            totalAmountTextView.text = item.totalAmount.toString()
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CostosViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.costos_view_holder,parent, false)
        return CostosViewHolder(view)
    }

    override fun onBindViewHolder(holder: CostosViewHolder, position: Int) {
        val item = data[position]
        holder.bindView(item)
    }

    override fun getItemCount(): Int {
        return data.size
    }
    fun addCase(case : Spend){
        data.add(case)
        this.notifyDataSetChanged()
    }

}