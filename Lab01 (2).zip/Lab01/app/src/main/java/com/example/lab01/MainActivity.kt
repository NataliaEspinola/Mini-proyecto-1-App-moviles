package com.example.lab01

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.navtest.Spend

class MainActivity : AppCompatActivity() {

    lateinit var  costosRecyclerView: RecyclerView
    lateinit var adapter: CostosRecyclerViewAdapter
    lateinit var cases: MutableList<Spend>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        costosRecyclerView = findViewById(R.id.costos_recycler_view)
        costosRecyclerView.layoutManager = LinearLayoutManager(this)
        adapter = CostosRecyclerViewAdapter()
        costosRecyclerView.adapter = adapter
        cases = MutableList<Spend>()
        val add1Button = findViewById<Button>(R.id.plus1)
        val add5Button = findViewById<Button>(R.id.plus5)
        add1Button.setOnClickListener {
            adapter.addCase(cases[0])
        }
        add5Button.setOnClickListener {
            adapter.addCase(cases[0])
            adapter.addCase(cases[0])
            adapter.addCase(cases[0])
            adapter.addCase(cases[0])
            adapter.addCase(cases[0])
        }

    }

    private fun <T> MutableList(): MutableList<Spend> {
        TODO("Not yet implemented")
    }
}